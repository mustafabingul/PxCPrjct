from audioop import add
import docx
import re
import os
import glob
import sys

REGEXP = r'\b[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][ABD-HJLNP-UW-Z]{2}\b'

def extract_all_addresses(path):
    docx_files = glob.glob(os.path.join(path, "*.docx"))

    # loop over the list of docx files
    for f in docx_files:
        
        # read the csv file
        doc = docx.Document(f)
        data = ""
        fullText = []
        for para in doc.paragraphs:
            fullText.append(para.text)
            data = '\n'.join(fullText)
        # print the location and filename
        #print('Location:', f)
        address = re.findall(REGEXP, data)
        print('File Name:', f.split("\\")[-1])
        if len(address) > 0:
            print('Address:', ', '.join(address))
        else:
            print('Address: NO ADDRESS')
        print()

def main():
    if len(sys.argv) != 2:
        print("usage   :::: python task2.py [folder path]")
        print("example :::: python task2.py C:\\development\\Tasks\\Tasks\\Task2\\test_docs")
        sys.exit()
    path = str(sys.argv[1]) 
    #'C:\\Users\\mbingul\\Downloads\\Tasks\\Tasks\\Task2\\test_docs
    extract_all_addresses(path)

if __name__ == "__main__":
    sys.exit(main())
