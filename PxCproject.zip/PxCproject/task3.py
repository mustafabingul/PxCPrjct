import docx
import re
import os
import glob
import sys

LETTERKEYWORDS = ["Dear","Sincerely,","Thank you","Kind regards","Hi","Best wishes","Respectfully", "To whom it may concern"]

def analyze_files(path):
    docx_files = glob.glob(os.path.join(path, "*.docx"))

    # loop over the list of docx files
    for f in docx_files:
        
        # read the csv file
        doc = docx.Document(f)
        data = ""
        fullText = []
        for para in doc.paragraphs:
            fullText.append(para.text)
            data = '\n'.join(fullText)
        # print the location and filename
        # print(doc.core_properties.author)        
        #print('Location:', f)
        print('File Name:', f.split("\\")[-1])
        common = list(set(data.strip().split()) & set(LETTERKEYWORDS))
        if len(common) > 0:
            print("LETTER")
        else:
            print("CONTRACT")
        print()
     
def main():
    if len(sys.argv) != 2:
        print("usage   :::: python task3.py [folder path]")
        print("example :::: python task3.py C:\\development\\Tasks\\Tasks\\Task3\\test_docs")
        sys.exit()
    path = str(sys.argv[1])
    #'C:\\Users\\mbingul\\Downloads\\Tasks\\Tasks\\Task3\\test_docs
    analyze_files(path)

if __name__ == "__main__":
    sys.exit(main())
