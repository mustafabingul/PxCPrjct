# import necessary libraries
import pandas as pd
import os
import glob
import xlsxwriter
import sys

APPROVED = 'Approved'

def determine_all_approved_lines(path):
    csv_files = glob.glob(os.path.join(path, "*.xlsx"))
    workbook = xlsxwriter.Workbook('ResultTask1.xlsx')
    # By default worksheet names in the spreadsheet will be
    worksheet = workbook.add_worksheet("All Approved Results")

    row = 0
    col = 0   

    # loop over the list of csv files
    for f in csv_files:
        
        # read the csv file
        df = pd.read_excel(f)
        
        # print the location and filename
        #print('Location:', f)
        #print('File Name:', f.split("\\")[-1])
        myList = df.values.tolist()
        
        # Iterate over the data and write it out row by row
        for name, status in (myList):
            if status == APPROVED:
                worksheet.write(row, col, name)
                worksheet.write(row, col + 1, status)
                row += 1        
        #print()
    workbook.close()

def main():
    if len(sys.argv) != 2:
        print("usage   :::: python task1.py [folder path]")
        print("example :::: python task1.py C:\\development\\Tasks\\Tasks\\Task1")
        sys.exit()
    path = str(sys.argv[1]) 
    #'C:\\Users\\mbingul\\Downloads\\Tasks\\Tasks\\Task1'
    determine_all_approved_lines(path)    

if __name__ == "__main__":
    sys.exit(main())